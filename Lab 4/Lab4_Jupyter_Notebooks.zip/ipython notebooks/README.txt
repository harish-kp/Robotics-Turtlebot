"""
Created on Thu Sept 1 11:06:15 2016
@author: admin-u5941570

"""

ipython notebooks are meant to be used for your Task2.

HOW TO:

    1- Either download ipython notebook $sudo apt-get install python-notebook or run it online on http://jupyter.org/
    adding the line "%matplotlib notebook" to enable animation on figures.
    2- If you choose to run it on your machine, in a new terminal, change directory to where you have saved your 
    ipython notebooks, then type $ipython notebook and "play" each block of the the file.
    3- If you choose to run it online, upload your ipython to jupyter, add the line "%matplotlib notebook" and 
    crtl+enter to run each block of the file.
    3- Change parameters and report your findings as explained in the turorial/lab.
    
